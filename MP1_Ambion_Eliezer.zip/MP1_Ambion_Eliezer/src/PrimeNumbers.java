import java.util.Scanner;
public class PrimeNumbers {
    public static void main(String[] args){
        int number;
        boolean isprime = true;
        int choose;
        int q2, q3, i, flag, temp;
        
        
        
        System.out.println("Menu:");
        System.out.println("1 Prime or Composite");
        System.out.println("2 All Prime numbers");
        System.out.println("3 Exit\n\nChoose from Menu");
        Scanner choices = new Scanner(System.in);
        choose = choices.nextInt();
         
        switch(choose){
            case 1:
                System.out.println("\nYou have chosen Prime and Composite");break;      
            case 2:
                System.out.println("\nYou have chosen All prime numbers");break;                
            case 3:
                System.out.println("\nExiting, Goodbye!");break;
        }
        if(choose == 1){
        
        Scanner input = new Scanner(System.in);
        System.out.println("Choose a number: ");
        number = input.nextInt();
        //input.close();       

        
        
        if(number == 1)
            System.out.println(number +" is neither prime nor composite");
        else if (number == 0)
            System.out.println(number +" is neither prime nor composite");
            else {
                for(int divisor = 2; divisor <= (number/2); divisor++){
                    if((number % divisor) == 0){
                    isprime = false;
                    break;
                }
                }
            if( isprime )
                System.out.println(number +" is a prime number");
            else
                System.out.println(number +" is composite number");
            }        
        }
         if(choose == 2){
            Scanner determine = new Scanner(System.in);
            System.out.println("Enter your two numbers: ");
            q2 = determine.nextInt();
            q3 = determine.nextInt();
 
            //Scanner determine2 = new Scanner(System.in);
            //System.out.println("Enter your second number: ");
            
            
         if(q2>q3)
         {
             temp=q2;
             q2=q3;
             q3=temp;
         }
            System.out.println("Prime numbers between " + q2 + " " + q3);
            if(q2<q3)
            {
                flag=0;
                for(i=2; i<=q2/2; q2++)
                {
                    if(q2 % i ==0)
                    {
                        flag=1;
                        break;
                    }
                }
                if(flag==0)
                    System.out.println("\t"+q2);
                q2++;
            }
         }
    }
    
}