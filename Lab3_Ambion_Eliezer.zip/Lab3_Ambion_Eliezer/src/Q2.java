
import javax.swing.JOptionPane;
public class Q2 {
    public static void main(String args[]){
        
        String name, address, number;
        int age;
        
        
        
        name = JOptionPane.showInputDialog("What is your name? ");
        age = Integer.parseInt(JOptionPane.showInputDialog("Age: "));
        address = JOptionPane.showInputDialog("Address: ");
        number = JOptionPane.showInputDialog("Number: ");
        
        String msg = "Name: " + name + "\nAge: "+ age + "\nAddress: " + address + "\nNumber: " + number;
        var msgs = "Age: " + age;
        JOptionPane.showMessageDialog(null, msg);
        
        
    }
    
}
