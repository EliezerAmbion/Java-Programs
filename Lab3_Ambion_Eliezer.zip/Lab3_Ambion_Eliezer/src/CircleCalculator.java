import java.util.Scanner;
class CircleCalculator {
    public static void main(String args [])
    {
    double radius, area, circum, diam;
    
    Scanner input = new Scanner(System.in);
    
        System.out.println("Enter radius: ");//output
        radius = input.nextDouble();//input
        input.close();
        
        area = Math.PI * radius * radius;
        System.out.println("The area of the circle is: " + area);
        
        circum = 2 * Math.PI * radius;
        System.out.println("The circumference of the circle is: " + circum);
        
        diam = (2 * radius);
        System.out.println("The diameter of the circle is:" + diam);
     
    
    }
}
