package MP3_Ambion_Eliezer;

import java.text.*;

public class BankAccountAmbion {

    private String name;
    private String address;
    private String birthday;
    private String contactNo;
    private int accountNo;
    private double iDeposit;

    public BankAccountAmbion() {
    }

    public BankAccountAmbion(String name, String address, String birthday, String contactNo, int accountNo, double iDeposit) {

        this.name = name;
        this.address = address;
        this.birthday = birthday;
        this.contactNo = contactNo;
        this.accountNo = accountNo;
        this.iDeposit = iDeposit;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    public int getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(int accountNo) {
        this.accountNo = accountNo;
    }
    
    public double getiDeposit(){
        return iDeposit;
    }
    
    public void setiDeposit(double iDeposit){
        this.iDeposit = iDeposit;
    }

    public String toString() {
        return "\nName: " + name + "\nAddress: " + address + "\nBirthday: " + birthday
                + "\nContact Number: " + contactNo + "\nYour intitial deposit is: " + iDeposit +"\nAccount Number: " + accountNo;
                
    }

}
