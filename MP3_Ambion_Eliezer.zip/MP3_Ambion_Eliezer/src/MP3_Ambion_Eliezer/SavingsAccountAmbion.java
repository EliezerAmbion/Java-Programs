package MP3_Ambion_Eliezer;

import java.util.ArrayList;
import java.util.List;
import java.text.*;

public class SavingsAccountAmbion extends BankAccountAmbion {

    private double balance;
    private double deposit;
    private double withdraw;
    private double amount;
    private double iDeposit;
    private List<BankAccountAmbion> listOfEntries;

    public SavingsAccountAmbion() {
        this.listOfEntries = new ArrayList<>();
    }

    public SavingsAccountAmbion(double balance, double deposit, double withdraw, double amount) {
        
        this.balance = balance;
        this.deposit = deposit;
        this.withdraw = withdraw;
        this.amount = amount;
        

    }
    
    public void add(BankAccountAmbion addressBookEntry) {
    //List.add adds a new Object to a List
    this.listOfEntries.add(addressBookEntry);
}
    public void delete(int index) {
    //List.remove(int index) removes an object at the given index
    this.listOfEntries.remove(index);
}
    public BankAccountAmbion get(int index) {
    //List.get(int index) returns the object at the given index
    return this.listOfEntries.get(index);
    }
    public BankAccountAmbion[] viewAll() {
    //create a new array with the size of our list
    BankAccountAmbion[] result = new BankAccountAmbion[this.listOfEntries.size()];

    //List.toArray(Arr[] array) fills our array with data from the list
    this.listOfEntries.toArray(result);
    return result;
}
    
    
    public double getBalance() {
        return balance;
    }
    public void setBalance(double balance) {
        this.balance = balance;
    }

    
    public double getDeposit() {      
        return deposit;
    }
    public void setDeposit(double deposit) {
        this.deposit = deposit;
    }

    
    public double getWithdraw() {              
        return withdraw;
    }
    public void setWithdraw(double withdraw) {
        this.withdraw = withdraw;
        
    }
    
    public double getAmount() {
        return amount;
    }
    public void setAmbount(double withdraw) {
        this.amount = amount;
    }
    
    public String priWithdraw(){
        return  "Your withdraw input is: "+withdraw+ "\nYour balance is now: " + (deposit - amount);
    }
    
    public String printDeposit(){
        return  "Your deposit input is: "+deposit+ "\nYour balance is now: " + deposit + "\n";
    }

}
