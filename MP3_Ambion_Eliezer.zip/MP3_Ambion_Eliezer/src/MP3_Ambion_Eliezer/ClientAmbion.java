package MP3_Ambion_Eliezer;

import static java.util.Map.entry;
import java.util.Scanner;
import java.util.*;

public class ClientAmbion {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        String input;
        String name = "";
        String address = "";
        String birthday = "";
        String contactNo = "";
        double withdraw = 0.00;
        double balance = 0.00;
        double iDeposit = 0.00;
        int accountNo = 0000;
        final int MAX = 9999;

        SavingsAccountAmbion addressBook = new SavingsAccountAmbion();

        do {
            System.out.print("\n****************************");
            System.out.println("\t\nJBANK MAIN MENU");
            System.out.println("\t[1] New Account"
                    + "\n\t[2] Balance Inquiry"
                    + "\n\t[3] Deposit"
                    + "\n\t[4] Withdraw"
                    + "\n\t[5] Client Profile"
                    + "\n\t[6] Close Account"
                    + "\n\t[7] Exit");
            System.out.println("****************************");
            System.out.print("Choose: ");//user choice
            input = in.next();//store user input

            switch (input) {
                case "1":
                    Random rand = new Random();
                    accountNo = rand.nextInt(MAX);

                    BankAccountAmbion entry = new BankAccountAmbion(name, address, birthday, contactNo, accountNo, iDeposit);

                    System.out.println("\nEnter your new Account details:");
                    System.out.print("Account Name: ");
                    entry.setName(in.next());

                    System.out.print("Address: ");
                    entry.setAddress(in.next());

                    System.out.print("Birthday: ");
                    entry.setBirthday(in.next());

                    System.out.print("Contact Number: ");
                    entry.setContactNo(in.next());

                    System.out.println("\nWhat amount would you like to put as your initial deposit? (Should not be less than Php5,000):");
                    entry.setiDeposit(in.nextDouble());

                    addressBook.add(entry);

                    System.out.println(entry.toString());
                    System.out.println("Entry Added\n");
                    System.out.println("Please take note of your Account Number. Thank you!\n\n");
                    break;

                    
                case "2"://balance inquiry
                    SavingsAccountAmbion bal = new SavingsAccountAmbion();

                    System.out.println(bal.getBalance());
                    break;

                    
                case "3"://deposit
                    SavingsAccountAmbion dep = new SavingsAccountAmbion();
                    System.out.println("\nHow much do you want to deposit?");
                    dep.setDeposit(in.nextDouble());
                    System.out.println(dep.printDeposit());
                    break;

                    
                case "4"://withdraw
                    SavingsAccountAmbion hm = new SavingsAccountAmbion();
                    System.out.println("\nEnter your account number: ");

                    System.out.println("How much do you want to withdraw?");
                    hm.setWithdraw(in.nextDouble());
                    System.out.println(hm.priWithdraw());
                    break;

                    
                case "5"://client profile
                    System.out.println("Enter your account Number:");//should get the account number

                    System.out.println("All of your Entries:");
                    //get array of all entries
                    BankAccountAmbion[] listOfEntries = addressBook.viewAll();

                    //for every entry in the array
                    for (int i = 0; i < listOfEntries.length; i++) {
                        System.out.println(listOfEntries[i].toString());
                    }
                    break;

                    
                case "6"://close account
                    System.out.println("Enter the index of the entry, which you want to delete:");                   
                    addressBook.delete(in.nextInt());
                    break;

                    
                case "7":
                    System.out.println("Exiting...\nGoodbye!");
                    break;

                    
                default:
                    System.out.println("INVALID INPUT!\nTry again.\n\n");
                    break;

            }

        } while (!input.equals("7"));

    }

}
