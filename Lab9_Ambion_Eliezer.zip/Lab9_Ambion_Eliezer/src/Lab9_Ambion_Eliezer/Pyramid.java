package Lab9_Ambion_Eliezer;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Pyramid {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int rows;
        boolean bool = true;

        do {
            try {
                System.out.println("How many rows would you like me to print?: ");
                rows = in.nextInt();

                if (rows <= 1) {
                    System.out.println("Values less than 2 are invalid inputs. Enter again.\n");
                } else {
                    for (int a = 1; a <= rows; a++) {
                        for (int b = 1; b <= a; b++) {
                            System.out.printf("*");
                        }
                        System.out.println();
                        bool = false;
                    }   
                }

            } catch (InputMismatchException e) {
                System.out.println("Invalid! Please input numeric values\n");
                bool = true;
                in.nextLine();
            }

        } while (bool);
    }
}
