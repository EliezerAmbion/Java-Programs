package Lab9_Ambion_Eliezer;

public class ExceptionTest {

    public static void main(String[] args) {

        String nums[] = {"one", "two", "three"};

        try {
            for (int i = 0; i <= 3; i++) {
                System.out.println(nums[i]);

            }
        } catch (Exception e) {
            System.out.println("Exception caught: " + e + "\n");

        }
    }
}
