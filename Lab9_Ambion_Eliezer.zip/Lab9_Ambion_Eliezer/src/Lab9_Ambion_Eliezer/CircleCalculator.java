package Lab9_Ambion_Eliezer;

import java.util.Scanner;

class CircleCalculator {

    public static void main(String args[]) {
        double radius, area, circum, diam, in;

        Scanner input = new Scanner(System.in);
        boolean bool = true;
        
        do{
            bool = false;
            
            try {
                System.out.println("Enter radius: ");//output
                radius = input.nextDouble();//input
                input.close();

                area = Math.PI * radius * radius;
                System.out.println("The area of the circle is: " + area);

                circum = 2 * Math.PI * radius;
                System.out.println("The circumference of the circle is: " + circum);

                diam = (2 * radius);
                System.out.println("The diameter of the circle is:" + diam);
                
            } catch (Exception e) {
                System.out.println("\nInvalid! Please input a NUMBER.\n");
                bool = true;
                input.nextLine();//I use nextLine for letter inputs.
            }    
        }while(bool); 
    }
}
