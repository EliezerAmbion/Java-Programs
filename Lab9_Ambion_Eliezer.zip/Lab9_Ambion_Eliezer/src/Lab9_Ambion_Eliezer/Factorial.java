package Lab9_Ambion_Eliezer;

import java.util.Scanner;

public class Factorial {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        long factorial = 1;
        boolean bool = true;
        int number;

        do {
            bool = false;
            try {
                System.out.println("\nEnter a number: ");
                number = scan.nextInt();

                if (number < 0) {
                    System.out.println("Invalid Input\nTry again.\n");
                    bool = true;

                } else if (number <= 1) {
                    System.out.printf("The factorial of %d is 1\n", number);
                    
                } else {
                    for (int i = number; i >= 2; i--) {
                        factorial = factorial * i;
                        System.out.printf("Factorial of %d is %d\n", number, factorial);
                    }
                }
            } catch (Exception e) {
                System.out.println("Invalid! Please use numeric values only.");
                bool = true;
                scan.next();
            }

        } while (bool);
    }
}
