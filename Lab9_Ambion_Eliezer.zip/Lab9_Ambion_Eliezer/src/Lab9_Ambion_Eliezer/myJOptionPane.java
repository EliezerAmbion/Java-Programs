package Lab9_Ambion_Eliezer;

import javax.swing.JOptionPane;

public class myJOptionPane {

    public static void main(String args[]) {

        String name, address, number;
        int age = 0;
        boolean bool = true;

        name = JOptionPane.showInputDialog("What is your name? ");
        address = JOptionPane.showInputDialog("Address: ");
        number = JOptionPane.showInputDialog("Number: ");

        //the age is the only int here so this will only be the one that I will be using try catch
        do{
            bool = false;
            try {
                age = Integer.parseInt(JOptionPane.showInputDialog("Age: "));

            } catch (Exception e) {
               JOptionPane.showMessageDialog(null, "Please use numeric values only", null, JOptionPane.ERROR_MESSAGE);
                bool = true;
            }

        } while(bool);
        
         String msg = "Name: " + name + "\nAge: " + age + "\nAddress: " + address + "\nNumber: " + number;
            JOptionPane.showMessageDialog(null, msg);

    }

}
