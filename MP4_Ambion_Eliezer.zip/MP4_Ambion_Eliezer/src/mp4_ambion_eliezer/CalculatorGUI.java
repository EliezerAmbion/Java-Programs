package mp4_ambion_eliezer;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

//PLEASE HOVER THE MOUSE ON THE EMPTY AREA
public class CalculatorGUI extends JFrame implements ActionListener {//JFrame is the superclass and the CalculatorGUI is the subclass

    JLabel Label1, Label2, Label3;
    JButton addi, sub, min, mul;
    JTextField Text1, Text2;
    JPanel panel;
    JTextArea textArea;

    public static void main(String[] args) {//MAIN METHOD
        CalculatorGUI obj = new CalculatorGUI();
    }

    private CalculatorGUI() {//method

        super("Simple Calculator");//You can put the title here and you need to extend JFrame
        setVisible(true);
        setSize(340, 260);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);     
        panel = new JPanel();
        add(panel);
       
        //Labels
        Label1 = new JLabel("First Number:");
        Label1.setBounds(10, 20, 80, 25);
        add(Label1);

        Label2 = new JLabel("Second Number:");
        Label2.setBounds(10, 50, 100, 25);
        add(Label2);
        
        Label3 = new JLabel("Result:");
        Label3.setBounds(10, 80, 150, 25);
        add(Label3);
        
        
        //TextFields
        Text1 = new JTextField(8);
        Text1.setBounds(150, 20, 165, 25);
        add(Text1);

        Text2 = new JTextField(8);
        Text2.setBounds(150, 50, 165, 25);
        add(Text2);


        //BUTTONS WITH ActionListener
        //Without ActionListener, the buttons are useless
        
        
        //IF THE BUTTONS DOESN'T APPEAR, HOVER THE MOUSE ON THE EMPTY SPACE 
        
        //ADD
        JButton addi = new JButton("ADD");
        addi.setBounds(15, 110, 110, 25);
        add(addi);
        addi.addActionListener(new ActionListener() {//start parenthesis is here
            @Override
            public void actionPerformed(ActionEvent e) {
                double num1 = Integer.parseInt(Text1.getText());
                double num2 = Integer.parseInt(Text2.getText());
                double answer = num1 + num2;
                
                Label3.setText("Result:   " + answer);
            }
        });//end parenthesis is here
        

        //SUBTRACT
        JButton sub = new JButton("SUBTRACT");
        sub.setBounds(15, 140, 110, 25);
        add(sub);
        sub.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double num1 = Integer.parseInt(Text1.getText());
                double num2 = Integer.parseInt(Text2.getText());
                double answer = num1 - num2;
                
                Label3.setText("Result:   " + answer);
            }
        });
        

        //DIVIDE
        JButton min = new JButton("DIVIDE");
        min.setBounds(190, 110, 110, 25);
        add(min);
        min.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double num1 = Integer.parseInt(Text1.getText());
                double num2 = Integer.parseInt(Text2.getText());
                double answer = num1 / num2;
                
                Label3.setText("Result:   " + answer);

            }
        });

        
        //MULTIPLY
        JButton mul = new JButton("MULTIPLY");
        mul.setBounds(190, 140, 110, 25);
        add(mul);
        mul.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double num1 = Integer.parseInt(Text1.getText());
                double num2 = Integer.parseInt(Text2.getText());
                double answer = num1 * num2;
                
                Label3.setText("Result:   " + answer);
            }
        });
        
        
        //RESET
        JButton reset = new JButton("RESET");
        reset.setBounds(15, 170, 110, 25);
        add(reset);
        reset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Text1.setText("");
                Text2.setText("");
            }
        });
        
        
        //QUIT
        JButton quit = new JButton("QUIT");
        quit.setBounds(190, 170, 110, 25);
        add(quit);
        quit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              JFrame frame = new JFrame("EXIT");           
               if(JOptionPane.showConfirmDialog(frame, "Do you want to exit?", "EXIT", 
                       JOptionPane.YES_OPTION) == JOptionPane.YES_OPTION)
                {
                    System.exit(0);
                }
              
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
