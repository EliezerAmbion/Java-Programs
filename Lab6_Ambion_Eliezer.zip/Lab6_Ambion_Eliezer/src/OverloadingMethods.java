
import java.util.Scanner;


public class OverloadingMethods {
    public static void main(String args[]) {
        
        average(5, 6, 7);
        average(1, 2, 3, 4);
        average(10, 100);
    }
    
    public static void average(int x, int y, int z){
        System.out.println((x + y + z) / 3);
    }
    
    public static void average(int a, int b, int c, int d){
        System.out.println((a + b + c + d) / 4);
    }
    public static void average(int x, int y){
        System.out.println((x + y) / 2);
    }
}
