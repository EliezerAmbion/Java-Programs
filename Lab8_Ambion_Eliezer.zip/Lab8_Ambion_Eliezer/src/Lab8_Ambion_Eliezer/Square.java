package Lab8_Ambion_Eliezer;

public class Square extends Shape {

    double area;
    String name;    
    int aSquared = 5;

    @Override
    public void getArea() {
        area = aSquared * aSquared;
    }

    @Override
    public void getName() {
        name = "Square";
    }

    @Override
    public String toString() {
        String result = "Area of the " + name + " is " + area;
        return result;
    }
}
