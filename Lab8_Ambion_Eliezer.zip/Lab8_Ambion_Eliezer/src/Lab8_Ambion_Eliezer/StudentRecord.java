package Lab8_Ambion_Eliezer;

public class StudentRecord {

    String name;
    double mathGrade;
    double englishGrade;
    double scienceGrade;

    public StudentRecord() {
    }//needed this to call super keyword

    public StudentRecord(String name, double mathGrade, double englishGrade, double scienceGrade) {
        this.name = "";
        this.mathGrade = 0;
        this.englishGrade = 0;
        this.scienceGrade = 0;

    }

    public String getName() {
        return "\n\nName:\t\t" + name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMathGrade() {
        return "Math:\t\t" + mathGrade;
    }

    public void setMathGrade(double mathGrade) {
        this.mathGrade = mathGrade;
    }

    public String getEnglishGrade() {
        return "English:\t" +englishGrade;
    }

    public void setEnglishGrade(double englishGrade) {
        this.englishGrade = englishGrade;
    }

    public String getScienceGrade() {   
        return "Science:\t" +scienceGrade;
    }

    public void setScienceGrade(double scienceGrade) {
        this.scienceGrade = scienceGrade;
    }

    public double computeAverageGrade() {
        return (this.mathGrade + this.englishGrade + this.scienceGrade) / 3;
    }

}
