package Lab8_Ambion_Eliezer;

import java.util.Scanner;

public class Lab8Main {

    public static void main(String[] args) {
        //lab8 question number 1
        
        String name = "";
        double mathGrade = 0;
        double englishGrade = 0;
        double scienceGrade = 0;
        double comprogGrade = 0; 
        Scanner in = new Scanner(System.in);
        
        ComputerScienceStudentRecord rec = 
                new ComputerScienceStudentRecord(name, mathGrade, englishGrade, scienceGrade, comprogGrade);
        
        System.out.println("");
        System.out.print("Name: ");
        rec.setName(in.nextLine());
        System.out.print("Math: ");
        rec.setMathGrade(in.nextDouble());
        System.out.print("English: ");
        rec.setEnglishGrade(in.nextDouble());
        System.out.print("Science: ");
        rec.setScienceGrade(in.nextDouble());
        System.out.print("Computer Programming: ");
        rec.setComprogGrade(in.nextDouble());
 
        System.out.println(rec.getName());
        System.out.println(rec.getMathGrade());
        System.out.println(rec.getEnglishGrade());
        System.out.println(rec.getScienceGrade());
        System.out.println(rec.getComprogGrade());
        System.out.print("Average:\t");
        System.out.println(rec.computeAverageGrade());
        System.out.println("\n\n\n");
                
        
        
        //this is for lab8 question 2
        Circle circle = new Circle();
        circle.getArea();
        circle.getName();
        System.out.println(circle.getAreaName());

        Square square = new Square();
        square.getArea();
        square.getName();
        System.out.println(square.toString());

    }
}
