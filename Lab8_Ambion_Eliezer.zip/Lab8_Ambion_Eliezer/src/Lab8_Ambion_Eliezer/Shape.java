package Lab8_Ambion_Eliezer;

public abstract class Shape {

    public abstract void getArea();

    public abstract void getName();

}
