package Lab8_Ambion_Eliezer;

public class ComputerScienceStudentRecord extends StudentRecord {
   
    double comprogGrade;

    public ComputerScienceStudentRecord(String name, double mathGrade, double englishGrade, double scienceGrade, double comprogGrade) {   
        super();       
        name = "";
        mathGrade = 0;
        englishGrade = 0;
        scienceGrade = 0;
        comprogGrade = 0;     
    }

    public String getComprogGrade() {
        return "Computer Programming:\t" + comprogGrade;
    }

    public void setComprogGrade(double comprogGrade) {
        this.comprogGrade = comprogGrade;
    }
    
    public double computeAverageGrade() {
        
        return (mathGrade + englishGrade + scienceGrade + comprogGrade) / 4;
    }

}
