package Lab8_Ambion_Eliezer;

public class Circle extends Shape {
    double area;
    String name;
    int radius = 4;

    @Override
    public void getArea() {
        area = Math.PI * radius * radius;
    }

    @Override
    public void getName() {
        name = "Circle";       
    }
    
    public String getAreaName(){
        String result = "";
        result = "Area of the " + name + " is " + area;
        return result;
    }
}
