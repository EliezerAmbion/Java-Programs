public class LabExercise2 {
	//question 2
	public static void main(String[] args) { 
		int x = 25;
		int y = 3;
		String z = "";
		double result = 0;
		
		
		
		System.out.println("Values:");
		System.out.println("First integer: " + x);
		System.out.println("Second integer: " + y);
		System.out.println("Result: " + result);
		System.out.println();//new line
		System.out.println("Arithmetic Operations");
		
		result = x+y;
		System.out.println("Sum: " + result);
		
		result = x-y;
		System.out.println("Difference: " + result);
		
		result = x*y;
		System.out.println("Product: " + result);
		
		result = x/y;
		System.out.println("Quotient: " + result);
		
		result = x+y;
		System.out.println("Average: " + result/2);
		
		z = (x>=y) ? "Max Integer" : "Minimum Integer";
		System.out.println (z + " is " + x);
		
		z = (x<=y) ? "Max Integer" : "Minimum Integer";
		System.out.println (z + " is " + y);
		
	}

}