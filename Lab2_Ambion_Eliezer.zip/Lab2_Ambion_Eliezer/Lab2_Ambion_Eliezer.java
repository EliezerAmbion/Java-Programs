public class LabExercise2 {
	//question 1
	public static void main(String[] args) { 
		String result = "";
		int a = 5;
		int b = a%2;
		
		result = (b==1) ? "Odd" : "Even";
		System.out.print(a + " is " + result);
	}

}