import java.util.Scanner;


public class Factorial {
    public static void main(String [] args){
    Scanner scan = new Scanner(System.in);
    Scanner again = new Scanner(System.in);
    long factorial = 1;
    String answer;
    int number;
            
        do{
            System.out.println("\nEnter a number: ");
            number = scan.nextInt();
            
            if(number < 0){
                System.out.println("Invalid Input");
                
            }
            else if(number <=1){
                System.out.printf("The factorial of %d is 1\n",number);break;
            }
            else{
                for(int i = number; i >=2; i--){
                factorial = factorial * i;
                    System.out.printf("Factorial of %d is %d\n",number,factorial);
                }break;
            }                 
        }
        while(true);        
    }
}
