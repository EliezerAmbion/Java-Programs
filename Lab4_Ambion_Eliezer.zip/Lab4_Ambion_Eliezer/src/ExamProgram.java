
import java.util.Scanner;


public class ExamProgram {
    public static void main(String [] args){
        String q1;
        String q2;
        String q3;
        String q4;
        String q5;
        int a = 0;
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Who is the national hero of the Philippines?");
        System.out.println("1. Jose Rizal");        
        System.out.println("2. Andres Bonificio");
        System.out.println("3. Juan Luna");
        System.out.println("4. Emilio Jacinto");
        System.out.println("Input the number of the correct answer: ");
        q1 = scan.nextLine();
        
        if(q1.equals ("1"))
        {
            System.out.println("Correct!\n\n");
            a++;
        }
        else{
            System.out.println("Incorrect! The correct answer is 1. Jose Rizal! Magaral ka!\n\n");
        }
        
        System.out.println("What is 1 + 99?");
        System.out.println("1. 99 ");        
        System.out.println("2. 98");
        System.out.println("3. 1000");
        System.out.println("4. 100");
        System.out.println("Input the number of the correct answer: ");
        q2 = scan.nextLine();
        
        if(q2.equals ("4"))
        {
            System.out.println("Correct!\n\n"); 
            a++;
        }
        else{
            System.out.println("Incorrect! The correct answer is 4. 100\n\n");
        }
        
        System.out.println("August 31 is what Holiday?");
        System.out.println("1. Christmas day");        
        System.out.println("2. National Heroes day");
        System.out.println("3. All souls day");
        System.out.println("4. NewYear");
        System.out.println("Input the number of the correct answer: ");
        q3 = scan.nextLine();
        
        if(q3.equals ("2"))
        {
            System.out.println("Correct!\n\n"); 
            a++;
        }
        else{
            System.out.println("Incorrect! The correct answer is 2. National Heroes Day.\n\n");
        }
        
          System.out.println("What does R.A.M. stands for?");
        System.out.println("1. Read All Memory");        
        System.out.println("2. Read Access Memory");
        System.out.println("3. Random Access Memory");
        System.out.println("4. None of the above");
        System.out.println("Input the number of the correct answer: ");
        q4 = scan.nextLine();
        
        if(q4.equals ("3"))
        {
            System.out.println("Correct!\n\n"); 
            a++;
        }
        else{
            System.out.println("Incorrect! The correct answer is 3. Random Access Memory.\n\n");
        }
        
       System.out.println("What is the capital of the Philippines?");
        System.out.println("1. Manila");        
        System.out.println("2. Cebu");
        System.out.println("3. Pasay");
        System.out.println("4. Quezon City");
        System.out.println("Input the number of the correct answer: ");
        q5 = scan.nextLine();
        
        if(q5.equals ("1"))
        {
            System.out.println("Correct!\n\n"); 
            a++;
        }
        else{
            System.out.println("Incorrect! The correct answer is 1. Manila.\n\n");
        }
        
     
        
        System.out.println(a + " Correct out of 5");
        System.out.println(100 * a/5 + "%");
    }
    
}
