
import java.util.Scanner;

public class HalfPyramid {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        do {
            System.out.println("How many rows would you like me to print?: ");
            int rows = scan.nextInt();

            if (rows <= 1) {
                System.out.println("Values less than 2 are invalid inputs. Enter again.\n");
            } else {
                for (int a = 1; a <= rows; a++) {
                    for (int b = 1; b <= a; b++) {
                        System.out.printf("*");
                    }
                    System.out.println();
                }
                break;
            }
        } while (true);
    }
}
