
import java.util.Scanner;


public class MinMax {
    
public static void main (String args[]){
Scanner scan=new Scanner(System.in);

int min,max;
int n=10;

int arr[]=new int[n];

for(int i=0; i<n; i++){
   System.out.print("Enter ten elements "+(i+1)+": ");
   arr[i]=scan.nextInt();//takes input from user for array
   }
   min=arr[0];//assume smallest value
   max=arr[0];//assume largest value
   for(int i=0; i<n; i++){
     if(min>arr[i]){//loop to find minimum elements
       min=arr[i];
     }
     
     if(max<arr[i]){
       max=arr[i];  //loop to find maximum elements
     }
   }
   System.out.print("\nThe smallest value is: \n"+min);
   System.out.print("\nThe largest value is: \n"+max);
}
}
