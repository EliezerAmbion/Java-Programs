
import java.util.Scanner;


public class OddEven {
  public static void main(String[] args) 
    {
        int n = 10;
        Scanner s = new Scanner(System.in);
      
        int a[] = new int[n];
        System.out.println("Enter Ten(10) numbers: ");
        for (int i = 0; i < n; i++) 
        {
            a[i] = s.nextInt();
        }
        System.out.println("\nOdd numbers: ");
        for(int i = 0 ; i < n ; i++)
        {
            if(a[i] % 2 != 0)
            {
                System.out.print(a[i]+" ");
            }
        }
        System.out.println("");
        System.out.println("\nEven numbers: \n");
        for(int i = 0 ; i < n ; i++)
        {
            if(a[i] % 2 == 0)
            {
                System.out.print(a[i]+" ");
            }
        }
    }
}
