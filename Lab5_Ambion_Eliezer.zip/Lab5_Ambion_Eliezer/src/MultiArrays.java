
public class MultiArrays {
    
    public static void main(String args[]){
        String [][] entry={{"010", "John", "Male", "21"},
            {"011", "Mary", "Female", "25"},
            {"012", "Joseph", "Male", "24"},
            {"013", "Peter", "Male", "22"}};
        
        for (int i=0;i<entry.length;i++){
            for (int j=0;j<entry[i].length;j++){
                if (j==0){System.out.println("\nID:"+entry[i][j]);
                }
                
                else if (j==1){
                    System.out.println("Name:"+entry[i][j]);
                
                }
                else if (j==2){System.out.println("Gender:"+entry[i][j]);
                }
                
                else if (j==3){System.out.println("Age:"+entry[i][j]);
                }
            }
        }
    }
}
