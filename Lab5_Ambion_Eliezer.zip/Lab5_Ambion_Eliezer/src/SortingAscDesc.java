
import java.util.Arrays;
import java.util.Scanner;


public class SortingAscDesc {
    public static void main(String [] args){
    Scanner scan = new Scanner(System.in);
    Scanner choose = new Scanner(System.in);
    int a, i, j, temp, choice;
    
        System.out.println("Enter Array length: ");
        a = scan.nextInt();//user inputs the length in a
        
        int[] leng = new int[a];//user inputs numbers in a
        
        System.out.println("\nEnter " +a+ " numbers: ");
        
        for (i = 0; i < a; i++) 
            leng[i] = scan.nextInt();
        
        System.out.println("1. Ascending\t 2. Descending.\nChoose: ");
        choice = choose.nextInt();//user inputs choice if asc or desc
        if(choice == 1){//ascending
        
            for (i = 0; i < ( a - 1 ); i++) {
                for (j = 0; j < a - i - 1; j++) {
                    if (leng[j] > leng[j+1]) 
        {
          temp = leng[j];
          leng[j] = leng[j+1];
          leng[j+1] = temp;
        }
                }
            }
 
    System.out.println("\nSorted elements in Ascending order:");
 
    for (i = 0; i < a; i++) 
      System.out.println(leng[i]);
            
        }
        else if(choice == 2){//descending
            
            for (i = 0; i < ( a - 1 ); i++) {
                for (j = 0; j < a - i - 1; j++) {
                    if (leng[j] < leng[j+1]) 
        {
          temp = leng[j];
          leng[j] = leng[j+1];
          leng[j+1] = temp;
        }
                }
            }
 
    System.out.println("\nSorted elements in Descending order:");
 
    for (i = 0; i < a; i++) 
      System.out.println(leng[i]);
        
        
        }
        else{
            System.out.println("Invalid!");
        }
    }
}
